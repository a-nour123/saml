<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class FixAssetCommentReadersForeignKey extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('asset_comment_readers', function (Blueprint $table) {
            // Drop the incorrect foreign key
            $table->dropForeign(['comment_id']);

            // Add the correct foreign key
            $table->foreign('comment_id')
                ->references('id')
                ->on('asset_comments')
                ->onDelete('cascade');
        });
    }

    public function down()
    {
        Schema::table('asset_comment_readers', function (Blueprint $table) {
            $table->dropForeign(['comment_id']);
            $table->foreign('comment_id')
                ->references('id')
                ->on('assets')
                ->onDelete('cascade');
        });
    }
}
