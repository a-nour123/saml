<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LMSComplianceTrainingModule extends Model
{
    use HasFactory;
    protected $table = 'l_m_s_compliance_training_modules';
    protected $guarded = [];
}
