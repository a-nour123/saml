@extends('admin/layouts/contentLayoutMaster')

@section('title', __('locale.Automated Discovery'))

@section('content')
<div class="row">
    <div class="col-12">
        <div class="alert alert-primary" role="alert">
            <div class="alert-body">
                Here in asset-management main route use this route in blade as <br><strong>route('admin.asset_management.index')</strong>
            </div>
        </div>
    </div>
</div>
@endsection
