<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="{{ csrf_token() }}" />
    <title>Cyber Mode</title>
    <link rel="apple-touch-icon" href="{{ asset(getSystemSetting('APP_FAVICON')) }}">
    <link rel="shortcut icon" type="image/x-icon" href="{{ asset(getSystemSetting('APP_FAVICON')) }}">
    <link rel="stylesheet" href="{{ asset('fonts/fontawesome-6.2.1/css/all.min.css') }}">
     <link rel="stylesheet" href="{{ asset('cdn/bootstrap.min.css') }}" />
     <script src="{{ asset('cdn/bootstrap.bundle.min.js') }}"></script>

     
    {{-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script> --}}
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/sweetalert2.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-sweet-alerts.css')) }}">
    <script src="{{ asset(mix('vendors/js/extensions/sweetalert2.all.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>

    <style>
        body {
            background-color: #f4f6f9;
            color: #333;
            font-family: Arial, sans-serif;
            padding: 20px;
        }

        .container {
            max-width: 800px;
            margin-top: 50px;
        }

        /* Styles for the "Back to Top" button */
        #backToTopBtn {
            position: fixed;
            bottom: 30px;
            right: 30px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 10px 15px;
            font-size: 14px;
            cursor: pointer;
            opacity: 0;
            transform: translateY(20px);
            /* Initial position for hiding animation */
        }

        /* Animation keyframes */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes fadeOutDown {
            from {
                opacity: 1;
                transform: translateY(0);
            }

            to {
                opacity: 0;
                transform: translateY(20px);
            }
        }

        /* Showing and hiding animations */
        #backToTopBtn.show {
            display: block;
            animation: fadeInUp 0.4s ease forwards;
        }

        #backToTopBtn.hide {
            animation: fadeOutDown 0.4s ease forwards;
        }

        /* Hover effect */
        #backToTopBtn:hover {
            background-color: #0056b3;
        }

        /* Card styling */
        .question-card,
        .remedation-card {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .btn-group {
            display: flex;
            gap: 1rem;
            justify-content: space-between;
        }

        @media (max-width: 768px) {
            .btn-group {
                flex-direction: column;
                gap: 0.5rem;
            }

            .container {
                padding: 20px;
            }
        }
    </style>
</head>

<body>

    <div class="container">

        {{-- checking email of third_party contact before answer questions --}}
        <div class="modal fade" id="emailModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
            aria-labelledby="emailModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="emailModalLabel">Enter your email</h1>
                        <button type="button" class="btn-close d-none" data-bs-dismiss="modal"
                            aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="form-floating mb-3">
                            <input type="email" class="form-control" id="contactEmail" name="contact_email"
                                placeholder="name@example.com">
                            <label for="contactEmail">Email address</label>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" id="submitCheckEmail" disabled class="btn btn-primary">Send</button>
                    </div>
                </div>
            </div>
        </div>

        {{-- checking password which send to email of third_party contact before answer questions --}}
        <div class="modal fade" id="passwordModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
            aria-labelledby="passwordModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="passwordModalLabel">Enter password which recived at mail</h1>
                        <button type="button" class="btn-close d-none" data-bs-dismiss="modal"
                            aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="form-floating mb-3">
                            <input type="password" class="form-control" id="accessPassword" name="access_password"
                                placeholder="name@example.com">
                            <label for="accessPassword">Password</label>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" id="submitCheckPassword" class="btn btn-primary">Send</button>
                    </div>
                </div>
            </div>
        </div>

        <form action="" id="questionnaireForm" class="form-control w-100 border-0 d-none">
            <h1 class="text-primary fw-bold text-center m-4">{{ $data['questionnaire']->name }}</h1>

            @if ($data['remedationNote'])
                <div class="remedation-card">
                    <label class="form-label mb-3">
                        <span class="text-primary fw-bold">Remedation note:</span>
                    </label>

                    <p>
                        {!! $data['remedationNote'] !!}
                    </p>
                </div>
            @endif

            <label class="form-label m-4">
                <span class="text-primary fw-bold">Assessment Instructions:</span>
                {{ $data['questionnaire']->instructions ?? 'No instructions available' }}
            </label>

            @php $x = 0 @endphp

            {{-- Check if latestResults has data, otherwise fallback to questions --}}
            @if (isset($data['latestResults']) && count($data['latestResults']) > 0)
                @foreach ($data['latestResults'] as $result)
                    @php $x++ @endphp
                    <div class="question-card">
                        <label class="form-label mb-3">
                            <span class="text-primary fw-bold">Question {{ $x }}:</span>
                            {{ $result->question }}
                        </label>
                        @foreach ($result->answers as $answer_id => $answer)
                            <div class="form-check mb-3">
                                <input class="form-check-input" type="radio"
                                    name="answer[{{ $result->question_id }}]" {{-- {{ $result->answer_id === $answer_id ? 'checked' : '' }} --}}
                                    @if ($result->answer_id === $answer_id) checked @endif value="{{ $answer_id }}"
                                    id="{{ $answer_id }}">
                                <label class="form-check-label" for="{{ $result->question_id }}"> {{ $answer }}
                                </label>
                            </div>
                        @endforeach
                        <div class="form-floating">
                            <textarea class="form-control" placeholder="Leave a comment here" id="comment[{{ $result->question_id }}]"
                                style="height: 100px">{{ $result->comment }}</textarea>
                            <label for="comment[{{ $result->question_id }}]">Comments</label>
                        </div>
                    </div>
                @endforeach
            @elseif(isset($data['questions']) && count($data['questions']) > 0)
                @foreach ($data['questions'] as $question)
                    @php $x++ @endphp
                    <div class="question-card">
                        <label class="form-label mb-3">
                            <span class="text-primary fw-bold">Question {{ $x }}:</span>
                            {{ $question->question }}
                        </label>
                        @foreach ($question->answers as $answer)
                            <div class="form-check mb-3">
                                <input class="form-check-input" type="radio" name="answer[{{ $question->id }}]"
                                    value="{{ $answer->id }}" id="{{ $answer->id }}">
                                <label class="form-check-label" for="{{ $answer->id }}"> {{ $answer->answer }}
                                </label>
                            </div>
                        @endforeach
                        <div class="form-floating">
                            <textarea class="form-control" placeholder="Leave a comment here" id="comment[{{ $question->id }}]"
                                style="height: 100px"></textarea>
                            <label for="comment[{{ $question->id }}]">Comments</label>
                        </div>
                    </div>
                @endforeach
            @endif

            <div class="btn-group">
                <button type="button" data-submission_type="draft"
                    class="btn btn-secondary submit_questionnaire_btn">Draft</button>
                <button type="button" data-submission_type="complete"
                    class="btn btn-primary submit_questionnaire_btn">Complete</button>
            </div>
        </form>


    </div>

    <!-- Back to Top Button -->
    <button id="backToTopBtn" onclick="scrollToTop()"><i class="fa-solid fa-arrow-up"></i></button>

    <script src="{{ asset('cdn/jquery-3.6.0.min.js') }}"></script>
    <script src="{{ asset('cdn/jquery.blockUI.min.js') }}"></script>

    <!-- Show/hide the "Back to Top" button based on scroll position -->
    <script>
        const backToTopBtn = document.getElementById("backToTopBtn");

        window.onscroll = function() {
            if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
                backToTopBtn.classList.add("show");
                backToTopBtn.classList.remove("hide");
                backToTopBtn.style.display = "block";
            } else {
                backToTopBtn.classList.add("hide");
                backToTopBtn.classList.remove("show");
            }
        };

        // Hide the button completely after fade-out animation ends
        backToTopBtn.addEventListener("animationend", (event) => {
            if (event.animationName === "fadeOutDown") {
                backToTopBtn.style.display = "none";
            }
        });

        function scrollToTop() {
            window.scrollTo({
                top: 0,
                behavior: "smooth"
            });
        }
    </script>

    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        var questionnaireId = `{{ $data['questionnaire']->id }}`;
        var currentContactId = `{{ $data['contact']->value('contact_id') }}`;
        var currentContactEmail = `{{ $data['contact']->value('contact_email') }}`;
        var accessPassword = {!! json_encode($data['access_password']) !!};

        $(document).ready(function() {
            // Automatically open the modal when the page loads
            $('#emailModal').modal('show');

            // Clear the email input field
            $("#contactEmail").val('');

            // Disable the submit button initially
            $("#submitCheckEmail").prop("disabled", true);
        });


        $(document).ready(function() {
            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/; // Basic email pattern for validation

            $("#contactEmail").on("input", function() {
                const email = $(this).val();

                // Remove previous validation classes and error message
                $(this).removeClass("is-invalid is-valid");
                $("#emailError").remove();

                if (!email) {
                    // If email is empty, add 'is-invalid' and disable the submit button
                    $(this).addClass("is-invalid");
                    $(this).after("<span id='emailError' class='text-danger'>Email is required.</span>");
                    $("#submitCheckEmail").prop("disabled", true);
                } else if (!emailPattern.test(email)) {
                    // If email format is invalid, add 'is-invalid' and disable the submit button
                    $(this).addClass("is-invalid");
                    $(this).after(
                        "<span id='emailError' class='text-danger'>Please enter a valid email address.</span>"
                    );
                    $("#submitCheckEmail").prop("disabled", true);
                } else {
                    // If email is valid, add 'is-valid' and enable the submit button
                    $(this).addClass("is-valid");
                    $("#submitCheckEmail").prop("disabled", false);
                }
            });
        });


        $("#submitCheckEmail").click(function(e) {
            e.preventDefault();

            // Clear any existing error message
            $("#contactEmail").removeClass("is-invalid");
            $("#emailError").remove(); // Remove existing error message if it exists

            if ($("#contactEmail").val() === currentContactEmail) {
                $('#emailModal').modal('hide');
                $('#passwordModal').modal('show');
            } else {
                $("#contactEmail").addClass("is-invalid");
                $("#contactEmail").after(
                    "<span id='emailError' class='text-danger'>This email address isn't valid with third party contact email.</span>"
                );
            }
        });

        $("#submitCheckPassword").click(function(e) {
            e.preventDefault();
            var enteredPassword = $("#accessPassword").val();

            // Clear any existing error message
            $("#accessPassword").removeClass("is-invalid");
            $("#passwordError").remove(); // Remove existing error message if it exists

            if (enteredPassword === accessPassword) {
                $('#passwordModal').modal('hide');
                $("#questionnaireForm").removeClass('d-none');
            } else {
                $("#accessPassword").addClass("is-invalid");
                $("#accessPassword").after(
                    "<span id='passwordError' class='text-danger'>Incorrect password.</span>"
                );
            }
        });

        // function of making alert
        function makeAlert($status, message, title) {
            // On load Toast
            if (title == 'Success')
                title = '👋' + title;
            toastr[$status](message, title, {
                closeButton: true,
                tapToDismiss: false,
            });
        }

        $(".submit_questionnaire_btn").click(function(e) {
            e.preventDefault();

            var submissionType = $(this).data('submission_type');

            // Initialize data object
            var data = {
                questionnaire_id: questionnaireId,
                contact_id: currentContactId,
                submission_type: submissionType,
                answers: [],
            };

            // Loop through each question card to collect responses
            $(".question-card").each(function() {
                var questionId = $(this).find("input[type='radio']").attr("name").match(/\d+/)[
                    0]; // Extract question ID
                var answer = $(this).find("input[type='radio']:checked").val();
                var comment = $(this).find("textarea").val(); // Get the comment text

                // If the answer is not found, set it to null
                if (answer === undefined) {
                    answer = null;
                }

                // Add the answer and comment to the data object
                data.answers.push({
                    question_id: questionId,
                    answer_id: answer,
                    comment: comment
                });
            });

            // console.log(data);

            $.ajax({
                type: "POST",
                url: '{{ route('admin.third_party.saveAnswers', ':id') }}'.replace(':id', questionnaireId),
                data: data,
                beforeSend: function() {
                    // Show loading overlay
                    $.blockUI({
                        message: '<div class="d-flex justify-content-center align-items-center"><p class="me-50 mb-0">{{ __('locale.PleaseWaitAction', ['action' => 'Answer Questions']) }}</p> <div class="spinner-grow spinner-grow-sm text-white" role="status"></div></div>',
                        css: {
                            backgroundColor: 'transparent',
                            color: '#fff',
                            border: '0'
                        },
                        overlayCSS: {
                            opacity: 0.5
                        }
                    });
                },
                success: function(response) {
                    Swal.fire({
                        position: 'center',
                        icon: 'success',
                        title: response.message,
                        showConfirmButton: false,
                        timer: 3000
                    }).then(function() {
                        window.location.reload();
                    });
                },
                error: function(xhr, status, error) {
                    $.unblockUI();

                    try {
                        // Parse the JSON response if available
                        var response = JSON.parse(xhr.responseText);

                        if (response.errors) {
                            // Display a single alert with all errors
                            Swal.fire({
                                icon: 'error',
                                title: "Please answer all questions",
                            });
                        }
                    } catch (e) {
                        // Fallback for unexpected responses or parse errors
                        console.error("Unexpected error format:", e, xhr.responseText);
                        Swal.fire({
                            icon: 'error',
                            title: 'Unexpected Error',
                            text: error,
                        });
                    }
                }
            });

        });
    </script>

</body>

</html>
