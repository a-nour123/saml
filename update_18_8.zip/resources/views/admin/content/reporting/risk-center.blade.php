@extends('admin/layouts/contentLayoutMaster')

@section('title', __('report.Overview'))
@section('vendor-style')
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/forms/select/select2.min.css')) }}">
@endsection
@section('page-style')

    <style>
        .container {
            background: rgba(255, 255, 255, 0.97);
            border-radius: 18px;
            padding: 32px 32px 32px 32px;
            box-shadow: 0 24px 48px rgba(0, 0, 0, 0.13);
            backdrop-filter: blur(12px);
            margin-bottom: 40px;
            border: 1.5px solid #e3e6f0;
            transition: box-shadow 0.3s;
        }

        .container:hover {
            box-shadow: 0 32px 64px rgba(102, 126, 234, 0.18);
        }

        .title {
            text-align: center;
            color: #333;
            margin-bottom: 30px;
            font-size: 2.2em;
            font-weight: 300;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .controls {
            display: flex;
            justify-content: center;
            gap: 15px;
            margin-bottom: 30px;
            flex-wrap: wrap;
        }

        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
        }

        .btn-secondary {
            background: linear-gradient(135deg, #f093fb, #f5576c);
            color: white;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
        }

        #tree-container-center {
            width: 100%;
            height: 600px;
            border: 2px solid #e0e0e0;
            border-radius: 12px;
            overflow: hidden;
            background: linear-gradient(45deg, #f8f9ff, #ffffff);
            position: relative;
        }

        .node circle {
            cursor: pointer;
            transition: all 0.3s ease;
            filter: drop-shadow(0 2px 4px rgba(0, 0, 0, 0.1));
        }

        .node circle:hover {
            transform: scale(1.1);
            filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.2));
        }

        .node text {
            font-weight: 600;
            font-size: 12px;
            text-shadow: 0 1px 2px rgba(255, 255, 255, 0.8);
        }

        .link {
            fill: none;
            stroke-width: 2;
            transition: all 0.3s ease;
        }

        .link:hover {
            stroke-width: 3;
        }

        .tooltip {
            position: absolute;
            background: linear-gradient(135deg, #232526 0%, #414345 100%);
            color: #fff;
            padding: 22px 26px;
            border-radius: 16px;
            font-size: 15px;
            line-height: 1.7;
            box-shadow: 0 12px 36px rgba(0, 0, 0, 0.32);
            backdrop-filter: blur(14px);
            max-width: 400px;
            z-index: 1000;
            pointer-events: none;
            opacity: 0;
            transition: opacity 0.3s cubic-bezier(.4, 2, .6, 1), transform 0.2s;
            border: 1.5px solid #4facfe;
            transform: translateY(10px) scale(0.98);
        }

        .tooltip.show {
            opacity: 1;
            transform: translateY(0) scale(1);
        }

        .tooltip-title {
            font-weight: bold;
            font-size: 19px;
            margin-bottom: 14px;
            color: #4facfe;
            letter-spacing: 0.5px;
            text-shadow: 0 2px 8px rgba(79, 172, 254, 0.08);
        }

        .tooltip-section {
            margin-bottom: 16px;
            padding-bottom: 10px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.13);
        }

        .tooltip-section:last-child {
            border-bottom: none;
            margin-bottom: 0;
        }

        .tooltip-label {
            font-weight: 600;
            color: #f093fb;
            display: inline-block;
            min-width: 120px;
            letter-spacing: 0.2px;
        }

        .risk-indicator {
            display: inline-block;
            width: 18px;
            height: 18px;
            border-radius: 4px;
            margin-left: 10px;
            vertical-align: middle;
            border: 1.5px solid #fff;
            box-shadow: 0 2px 8px rgba(245, 87, 108, 0.13);
        }


        .legend {
            position: absolute;
            top: 10px;
            right: 10px;
            background: rgba(255, 255, 255, 0.9);
            padding: 15px;
            border-radius: 8px;
            font-size: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .legend-item {
            display: flex;
            align-items: center;
            margin-bottom: 5px;
        }

        .legend-color {
            width: 16px;
            height: 16px;
            border-radius: 50%;
            margin-right: 8px;
            border: 1px solid #ccc;
        }

        .legend-color-center {
            background: #4facfe !important;
            border-color: #4facfe !important;
        }

        .legend-color-risk {
            background: #f093fb !important;
            border-color: #f093fb !important;
        }

        .legend-color-asset {
            background: #00b894 !important;
            border-color: #00b894 !important;
        }

        .legend-color-control {
            background: #0984e3 !important;
            border-color: #0984e3 !important;
        }

        .legend-color-exception {
            background: #fdcb6e !important;
            border-color: #fdcb6e !important;
        }

        .legend-color-threat {
            background: #e17055 !important;
            border-color: #e17055 !important;
        }

        .stats-panel {
            background: rgba(255, 255, 255, 0.9);
            padding: 15px;
            border-radius: 8px;
            margin-top: 20px;
            text-align: center;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }
    </style>
@endsection
@section('content')
    <div class="content-header row">
        <div class="content-header-left col-12 mb-2">

            <div class="row breadcrumbs-top  widget-grid">
                <div class="col-12">
                    <div class="page-title mt-2">
                        <div class="row">
                            <div class="col-sm-6 ps-0">
                                @if (@isset($breadcrumbs))
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}"
                                                style="display: flex;">
                                                <svg class="stroke-icon">
                                                    <use href="{{ asset('fonts/icons/icon-sprite.svg#stroke-home') }}">
                                                    </use>
                                                </svg></a></li>
                                        @foreach ($breadcrumbs as $breadcrumb)
                                            <li class="breadcrumb-item">
                                                @if (isset($breadcrumb['link']))
                                                    <a
                                                        href="{{ $breadcrumb['link'] == 'javascript:void(0)' ? $breadcrumb['link'] : url($breadcrumb['link']) }}">
                                                @endif
                                                {{ $breadcrumb['name'] }}
                                                @if (isset($breadcrumb['link']))
                                                    </a>
                                                @endif
                                            </li>
                                        @endforeach
                                    </ol>
                                @endisset
                        </div>

                    </div>
                </div>
            </div>

        </div>
    </div>
    <div id="quill-service-content" class="d-none"></div>

</div>
@php
    $riskLevelsJs = collect($riskLevels)
        ->map(function ($level) {
            return [
                'id' => $level->id,
                'value' => (float) $level->value,
                'name' => $level->name,
                'color' => $level->color,
            ];
        })
        ->sortBy('value')
        ->values()
        ->all();
@endphp
<div class="fluid-container">
    <h1 class="title">Risk Center</h1>
    <div class="controls">
        {{-- <button class="btn btn-primary" onclick="expandAll_center()">🔍 Expand All</button>
        <button class="btn btn-secondary" onclick="collapseAll_center()">📁 Collapse All</button> --}}
    </div>
    <div id="tree-container-center">
        <div class="legend">
            <div class="legend-item">
                <div class="legend-color" style="background: #4facfe;"></div>
                <span>Center</span>
            </div>
            @foreach ($riskLevels as $level)
                <div class="legend-item">
                    <div class="legend-color" style="background: {{ $level->color }};"></div>
                    <span>{{ ucfirst($level->name) }} Risk</span>
                </div>
            @endforeach
            <div class="legend-item">
                <div class="legend-color legend-color-asset"></div>
                <span>Asset</span>
            </div>
            <div class="legend-item">
                <div class="legend-color legend-color-control"></div>
                <span>Control</span>
            </div>
            <div class="legend-item">
                <div class="legend-color legend-color-exception"></div>
                <span>Exception</span>
            </div>
            <div class="legend-item">
                <div class="legend-color legend-color-threat"></div>
                <span>Threat</span>
            </div>
        </div>
    </div>
    <div class="tooltip" id="tooltip-center"></div>

</div>



@endsection

@section('vendor-script')
<script src="{{ asset(mix('vendors/js/forms/select/select2.full.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/charts/chart.min.js')) }}"></script>


@endsection


@section('page-script')
<script src="{{ asset(path: 'cdn/updated3.min.js') }}"></script>

<script>
    // Render the tree using backend $treeData as-is
    document.addEventListener('DOMContentLoaded', function() {
        const treeData = @json($treeData);
        const margin = {
            top: 40,
            right: 120,
            bottom: 40,
            left: 120
        };
        const width = 1000 - margin.left - margin.right;
        const height = 560 - margin.top - margin.bottom;
        const svg = d3.select('#tree-container-center')
            .append('svg')
            .attr('width', width + margin.left + margin.right)
            .attr('height', height + margin.top + margin.bottom);
        const g = svg.append('g')
            .attr('transform', `translate(${margin.left},${margin.top})`);
        const tree = d3.tree().size([height, width]);
        let root = d3.hierarchy(treeData, d => d.children);
        root.x0 = height / 2;
        root.y0 = 0;
        let i = 0;
        const duration = 750;

        function collapse(d) {
            if (d.children) {
                d._children = d.children;
                d._children.forEach(collapse);
                d.children = null;
            }
        }
        root.children && root.children.forEach(collapse);
        update(root);

        function update(source) {
            const treeData = tree(root);
            const nodes = treeData.descendants();
            const links = treeData.descendants().slice(1);
            nodes.forEach(d => {
                d.y = d.depth * 180;
            });

            const node = g.selectAll('g.node')
                .data(nodes, d => d.id || (d.id = ++i));

            const nodeEnter = node.enter().append('g')
                .attr('class', 'node')
                .attr('transform', d => `translate(${source.y0},${source.x0})`)
                .on('click', (event, d) => {
                    // If this is a risk node and we are expanding it, collapse all other risk nodes at the same level
                    if (d.data.type === 'risk' && (!d.children && d._children)) {
                        if (d.parent && d.parent.children) {
                            d.parent.children.forEach(sibling => {
                                if (sibling !== d && sibling.data.type === 'risk' && sibling
                                    .children) {
                                    sibling._children = sibling.children;
                                    sibling.children = null;
                                }
                            });
                        }
                    }
                    if (d.children) {
                        d._children = d.children;
                        d.children = null;
                    } else if (d._children) {
                        d.children = d._children;
                        d._children = null;
                    }
                    update(d);
                })
                .on('mouseover', showTooltip)
                .on('mouseout', hideTooltip);

            nodeEnter.append('circle')
                .attr('r', 1e-6)
                .style('fill', d => getNodeColor(d.data));

            // Update the text display logic to show appropriate names
            nodeEnter.append('text')
                .attr('dy', '.35em')
                .attr('x', d => d.children || d._children ? -13 : 13)
                .attr('text-anchor', d => d.children || d._children ? 'end' : 'start')
                .text(d => {
                    // For risk nodes, show "R" followed by the ID
                    if (d.data.type === 'risk') return 'R' + (d.data.id || '');
                    // For other node types, show appropriate names
                    if (d.data.type === 'asset') return d.data.details?.name || 'Asset';
                    if (d.data.type === 'exception') return d.data.details?.title || 'Exception';
                    if (d.data.type === 'control') return d.data.details?.name || 'Control';
                    if (d.data.type === 'threat') return d.data.details?.name || 'Threat';
                    return d.data.name || d.data.id;
                })
                .style('fill-opacity', 1e-6);

            const nodeUpdate = nodeEnter.merge(node);
            nodeUpdate.transition()
                .duration(duration)
                .attr('transform', d => `translate(${d.y},${d.x})`);
            nodeUpdate.select('circle')
                .attr('r', 8)
                .style('fill', d => getNodeColor(d.data))
                .attr('cursor', 'pointer');
            nodeUpdate.select('text')
                .style('fill-opacity', 1);

            const nodeExit = node.exit().transition()
                .duration(duration)
                .attr('transform', d => `translate(${source.y},${source.x})`)
                .remove();
            nodeExit.select('circle').attr('r', 1e-6);
            nodeExit.select('text').style('fill-opacity', 1e-6);

            const link = g.selectAll('path.link')
                .data(links, d => d.id);
            const linkEnter = link.enter().insert('path', 'g')
                .attr('class', 'link')
                .attr('d', d => {
                    const o = {
                        x: source.x0,
                        y: source.y0
                    };
                    return diagonal(o, o);
                })
                .style('stroke', '#ccc');
            const linkUpdate = linkEnter.merge(link);
            linkUpdate.transition()
                .duration(duration)
                .attr('d', d => diagonal(d, d.parent));
            link.exit().transition()
                .duration(duration)
                .attr('d', d => {
                    const o = {
                        x: source.x,
                        y: source.y
                    };
                    return diagonal(o, o);
                })
                .remove();

            nodes.forEach(d => {
                d.x0 = d.x;
                d.y0 = d.y;
            });
        }

        function diagonal(s, d) {
            const sx = (s && typeof s.x === 'number') ? s.x : 0;
            const sy = (s && typeof s.y === 'number') ? s.y : 0;
            const dx = (d && typeof d.x === 'number') ? d.x : 0;
            const dy = (d && typeof d.y === 'number') ? d.y : 0;
            return `M ${sy} ${sx}C ${(sy + dy) / 2} ${sx}, ${(sy + dy) / 2} ${dx}, ${dy} ${dx}`;
        }

        function getNodeColor(data) {
            if (data.type === 'center') return '#4facfe';
            if (data.type === 'risk') return data.details && data.details.color_inherent ? data.details
                .color_inherent : '#f093fb';
            if (data.type === 'asset') return '#00b894';
            if (data.type === 'control') return '#0984e3';
            if (data.type === 'exception') return '#fdcb6e';
            if (data.type === 'threat') return '#e17055';
            if (data.type === 'controls') return '#f093fb';
            if (data.type === 'exceptions') return '#764ba2';
            return '#ccc';
        }

        function showTooltip(event, d) {
            const tooltip = d3.select('#tooltip-center');
            let content = '';
            if (d.data.type === 'center') {
                content = `<div class='tooltip-title'>⚖️ Risk Center</div>`;
            } else if (d.data.type === 'risk') {
                content =
                    `<div class='tooltip-title'>⚠️ Risk: ${d.data.name}</div>
                    <div class='tooltip-section'><span class='tooltip-label'>Status:</span> ${d.data.details?.status ?? ''}</div>
                    <div class='tooltip-section'><span class='tooltip-label'>Subject:</span> ${d.data.details?.subject ?? ''}</div>
                    <div class='tooltip-section'><span class='tooltip-label'>Location:</span> ${d.data.details?.location ?? ''}</div>
                    <div class='tooltip-section'><span class='tooltip-label'>Team:</span> ${d.data.details?.team ?? ''}</div>
                    <div class='tooltip-section'><span class='tooltip-label'>Inherent Risk:</span> ${d.data.details?.inherent_risk ?? ''} <span class='risk-indicator' style='background:${d.data.details?.color_inherent ?? '#ccc'}'></span></div>`;
            } else if (d.data.type === 'asset') {
                const asset = d.data.details || {};
                content =
                    `<div class='tooltip-title'>🏢 Asset</div>
                    <div class='tooltip-section'><span class='tooltip-label'>IP:</span> ${asset.ip ?? ''}</div>
                    <div class='tooltip-section'><span class='tooltip-label'>Name:</span> ${asset.name ?? ''}</div>
                    <div class='tooltip-section'><span class='tooltip-label'>Owner Email:</span> ${asset.owner_email ?? ''}</div>
                    <div class='tooltip-section'><span class='tooltip-label'>Category:</span> ${asset.category ?? ''}</div>
                    <div class='tooltip-section'><span class='tooltip-label'>Asset Value:</span> ${asset.assetvalue ?? ''}</div>
                    <div class='tooltip-section'><span class='tooltip-label'>Location:</span> ${asset.location ?? ''}</div>`;
            } else if (d.data.type === 'control') {
                const control = d.data.details || {};
                content =
                    `<div class='tooltip-title'>🛡️ Control</div>
                    <div class='tooltip-section'><span class='tooltip-label'>Name:</span> ${control.name ?? ''}</div>
                    <div class='tooltip-section'><span class='tooltip-label'>Family:</span> ${control.family ?? ''}</div>
                    <div class='tooltip-section'><span class='tooltip-label'>Description:</span> ${control.description ?? ''}</div>
                    <div class='tooltip-section'><span class='tooltip-label'>Control Number:</span> ${control.control_number ?? ''}</div>
                    <div class='tooltip-section'><span class='tooltip-label'>Type:</span> ${control.control_type ?? ''}</div>
                    <div class='tooltip-section'><span class='tooltip-label'>Class:</span> ${control.control_class ?? ''}</div>
                    <div class='tooltip-section'><span class='tooltip-label'>Phase:</span> ${control.control_phase ?? ''}</div>
                    <div class='tooltip-section'><span class='tooltip-label'>Priority:</span> ${control.control_priority ?? ''}</div>
                    <div class='tooltip-section'><span class='tooltip-label'>Maturity:</span> ${control.control_maturity ?? ''}</div>
                    <div class='tooltip-section'><span class='tooltip-label'>Owner:</span> ${control.owner ?? ''}</div>`;
            } else if (d.data.type === 'exception') {
                const exception = d.data.details || {};
                content =
                    `<div class='tooltip-title'>🚩 Exception</div>
                    <div class='tooltip-section'><span class='tooltip-label'>Title:</span> ${exception.title ?? ''}</div>
                    <div class='tooltip-section'><span class='tooltip-label'>Creator:</span> ${exception.exception_creator ?? ''}</div>
                    <div class='tooltip-section'><span class='tooltip-label'>Request Duration:</span> ${exception.request_duration ?? ''}</div>
                    <div class='tooltip-section'><span class='tooltip-label'>Approval Date:</span> ${exception.approval_date ?? ''}</div>`;
            } else if (d.data.type === 'threat') {
                const threat = d.data.details || {};
                content =
                    `<div class='tooltip-title'>⚡ Threat</div>
                    <div class='tooltip-section'><span class='tooltip-label'>Name:</span> ${threat.name ?? ''}</div>
                    <div class='tooltip-section'><span class='tooltip-label'>Description:</span> ${threat.description ?? ''}</div>`;
            } else if (d.data.type === 'assets') {
                content = `<div class='tooltip-title'>🏢 Assets</div>`;
            } else if (d.data.type === 'controls') {
                content = `<div class='tooltip-title'>🛡️ Controls</div>`;
            } else if (d.data.type === 'exceptions') {
                content = `<div class='tooltip-title'>🚩 Exceptions</div>`;
            }
            tooltip.html(content).classed('show', true);
            // Smart positioning
            const container = document.getElementById('tree-container-center');
            const tooltipNode = tooltip.node();
            if (!tooltipNode) return; // Prevent error if tooltip element is missing
            const containerRect = container.getBoundingClientRect();
            const tooltipRect = tooltipNode.getBoundingClientRect();
            let x = event.clientX - containerRect.left + container.scrollLeft + 16;
            let y = event.clientY - containerRect.top + container.scrollTop - tooltipRect.height - 16;
            if (y < 0) y = event.clientY - containerRect.top + container.scrollTop + 24;
            if (x + tooltipRect.width > containerRect.width) x = containerRect.width - tooltipRect.width - 16;
            if (x < 0) x = 8;
            tooltip.style('left', x + 'px').style('top', y + 'px');
        }

        function hideTooltip() {
            d3.select('#tooltip-center').classed('show', false);
        }

        // window.expandAll_center = function() {
        //     function expand(d) {
        //         if (d._children) {
        //             d.children = d._children;
        //             d._children = null;
        //         }
        //         if (d.children) d.children.forEach(expand);
        //     }
        //     expand(root);
        //     update(root);
        // };
        // window.collapseAll_center = function() {
        //     function collapseAll(d) {
        //         if (d.children) {
        //             d._children = d.children;
        //             d.children = null;
        //         }
        //         if (d._children) d._children.forEach(collapseAll);
        //     }
        //     collapseAll(root);
        //     update(root);
        // };
    });
</script>
@endsection
