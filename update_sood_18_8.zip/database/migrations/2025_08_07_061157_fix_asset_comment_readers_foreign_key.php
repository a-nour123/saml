<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

class FixAssetCommentReadersForeignKey extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('asset_comment_readers', function (Blueprint $table) {
            // Disable foreign key checks temporarily
            DB::statement('SET FOREIGN_KEY_CHECKS=0;');
            
            // Truncate the table first
            DB::table('asset_comment_readers')->truncate();
            
            // Drop the existing foreign key
            $table->dropForeign(['comment_id']);
            
            // Add the correct foreign key
            $table->foreign('comment_id')
                ->references('id')
                ->on('asset_comments')
                ->onDelete('cascade');
                
            // Re-enable foreign key checks
            DB::statement('SET FOREIGN_KEY_CHECKS=1;');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('asset_comment_readers', function (Blueprint $table) {
            // Disable foreign key checks temporarily
            DB::statement('SET FOREIGN_KEY_CHECKS=0;');
            
            // Truncate the table first (optional in down method)
            DB::table('asset_comment_readers')->truncate();
            
            // Drop the foreign key
            $table->dropForeign(['comment_id']);
            
            // Revert to the previous foreign key
            $table->foreign('comment_id')
                ->references('id')
                ->on('assets')
                ->onDelete('cascade');
                
            // Re-enable foreign key checks
            DB::statement('SET FOREIGN_KEY_CHECKS=1;');
        });
    }
}