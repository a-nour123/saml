<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LMSUserTrainingModule extends Model
{
    use HasFactory;
    protected $table = 'l_m_s_user_training_modules';
    protected $guarded = [];
}
