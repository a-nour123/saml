<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LMSUserLevels extends Model
{
    use HasFactory;
    protected $table = 'l_m_s_user_levels';
    protected $guarded = [];
}
