<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rendered Form</title>
    <script src="https://appsforoffice.cdn.partner.office365.cn/appsforoffice/lib/1/hosted/office.js"></script>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://appsforoffice.cdn.partner.office365.cn/appsforoffice/lib/1/hosted/office.js"></script>
</head>

<body>

    <button class="btn btn-danger" type="submit">Submit For Test</button>

    {!! $website->html_code ??'' !!}
    <input type="hidden" name="PMTI" data-PMII={{ $emailId }}  data-PEI={{ $employeeId }} data-PCI={{ $campaignId }} id="P_data">

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        $(document).ready(function(){
            const mailOpenedUrl = "{!! route('mailForm.submited', ['PMTI' => '__PMTI__', 'PEI' => '__PEI__','PCI' => '__PCI__']) !!}";
            $(document).on('click','button[type=submit]',function(e){
                e.preventDefault();
                const emailId = $('#P_data').attr('data-PMII');
                const employeeId = $('#P_data').attr('data-PEI');
                const campaignId = $('#P_data').attr('data-PCI');

                console.log(emailId);
                console.log(employeeId);
                console.log(campaignId);

                const url = mailOpenedUrl.replace('__PMTI__', emailId).replace('__PEI__', employeeId).replace('__PCI__', campaignId);
                $.ajax({
                    url: url,
                    method: 'GET',
                    success: function(response) {
                        console.log(response);
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        console.log(textStatus, errorThrown);
                    }
                });
            })
        })
    </script>
</body>
</html>



