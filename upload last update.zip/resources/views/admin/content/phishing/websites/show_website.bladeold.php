{{-- <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{$website->name}}</title>
    <script src="https://appsforoffice.cdn.partner.office365.cn/appsforoffice/lib/1/hosted/office.js"></script>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://appsforoffice.cdn.partner.office365.cn/appsforoffice/lib/1/hosted/office.js"></script>
</head>

<body> --}}

    {!! $website->html_code  !!}

    {{-- <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html> --}}



