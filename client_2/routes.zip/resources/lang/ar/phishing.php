<?php

return array (
  'AddANewLandingPage' => 'Add A New LandingPage',
  'DuplicateLandingPage' => 'Duplicate LandingPage',
  'EditLandingPage' => 'Edit LandingPage',
  'Enter_a_unique_campaign_name' => 'أدخل اسم حملة فريد',
  'LandingPageWasUpdatedSuccessfully' => 'LandingPage Was Updated Successfully',
  'Managed' => 'Managed',
  'NewName' => 'اسم جديد',
  'Own' => 'Own',
  'Website' => 'Website',
  'WebsiteDomain' => 'WebsiteDomain',
  'WebsitePages' => 'Website Pages',
  'campaign_name' => 'اسم الحمله',
  'campaign_type' => 'نوع الحملة',
  'close' => 'Close',
  'content' => 'Content',
  'deleivery_schedual_note' => 'ملاحظة جدول التسليم',
  'description' => 'Description',
  'pageUrl' => 'page Url',
  'save' => 'Save',
  'Yearly_Phishing_Overview' => 'نظرة عامة على محاولات التصيد',
  'Yearly_Training_Overview' => 'نظرة عامة على التدريبات',
  'Phishing_Detailed_Reporting' => 'تقرير تفصيلي عن التصيد',
'Training_Detailed_Reporting' => 'تقرير تفصيلي عن التدريب',
'Phishing_Emails_Delivered' => 'رسائل التصيد المرسلة',
'Trainings_Assigned' => 'التدريبات المُسندة',



);
