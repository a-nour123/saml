
<?php

return array(
    'WebsitePages' => 'Website Pages',
    'Occurrences' => 'Case Type',
    'Directions' => 'Case Direction',
    'Attacks' => 'Attacks',
    'DetectedBy' => 'Detected By',
    'ImpactsValue' => 'Imapct Values',
    'LevelColor' => 'Levels Color',
    'IncidentGraph' => 'Impact Graph',
    'SiteLocation' => 'Site/Location',
    'IncidentScore' => 'Incident Assessment Score',
    'PlayBookCategory' => 'Play Book Category',
    'PlayBook' => 'Play Book',
    'IncidentScore' => 'Incident Score',
    'define_criteria' => 'Define Criteria',
    'scoring_system' => 'Scoring System',
    'classify_incident' => 'Classify Incident',
    'AddPlayBook' => 'Add  Play Book',
    'EditPlayBook' => 'Edit Play Book',
    'addAction' => 'Add Action',
    'PlayBookActions' => 'Play Book Actions',
    'configure' => 'Configure',
    'incident' => 'Incident',
    'existingAction' => 'Exist Actions',
    'newAction' => 'New Action',
    'NewAction' => 'New Action',
    'actions' => 'Actions',
    'IRA' =>'IRA',
    'Detection'=>'Detection',
    'Association'=>'Association',
    'incident_assessment' => 'Assessment',
    'assignment'=>'Assignment',
    'play_book' =>'Play Book',
    'Incident_management'=>'Incident Management',
    'summary' =>'Summary',
    'occurrence_name'=>'Case Type',
    'direction_name'=>'Direction',
    'attack_name'=>'Attack',
    'detected_name'=>'Detected By',
    'Detected_on'=>'Detected On',
    'details'=>'details',
    'occurrence_name'=>'Case Type',
    'Direction'=>'Direction',
    'Attack'=>'Attack',
    'Detect'=>'Detect',
    'status'=>'Status',
    'AddNewIncident'=>'Add New Incident',
    'open'=>'Open',
    'progress' => 'Progress',
    'closed'=>'Closed',
    'related_incident'=>'Related Incident',
    'related_risk' =>' Related Risks',
    'affected_asset' =>'Affected Asset',
    'source_tag' =>' Source tag',
    'destination_tag'=>'destination tag',
    'overall_incident' =>'Overall Incident',
    'open_incident'=>'Open Incident',
    'progress_incident'=>'Progress Incident',
    'closed_incident' =>'Closed Incident',
    'incident_impact'=>'Incident Impact',
    'incident_score'=>'Incident Score',
    'Case_type'=>'Case Type',
    'Reperted_by'=>'Reperted By',
    'Owned_by'=>'Owned By',
    'CSRIT'=>'CSRIT',
    'Containments'=>'Containments',
    'Eradications'=>'Eradications',
    'Recoveries'=>'Recoveries',
    'Score'=>'Score',
    'criteria'=>'Criteria',
    'score'=>'Score',
    'priority'=>'priority',
    'value'=>'value',
    'description'=>'description',
    'color'=>'color',
    'sla'=>'sla',
    'Classify'=>'Classify',
    'points'=>'points',
    'point'=>'Point',
    'actionTitle'=>'Action Title',
    'statistics'=>'Statistics',
    'ScoreClassify'=>'Incident Score Classify',
    'NumberOfIncident'=>'Number Of Incident',





























);
