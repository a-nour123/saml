<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SurveyQuestionAnswerController extends Controller
{
    //
}
