<?php

namespace App\Enums;

enum ApprovedStatusEnum: string
{
    case Yes = "yes";
    case No = "no";


}
