<?php

namespace App\Http\Controllers\admin\hierarchy;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class EmployeeController extends Controller
{
    public function index()
    {
        dd('index');
    }
}
