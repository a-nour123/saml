<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Services\MicrosoftGraphService;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Services\MicrosoftGraphServiceAuth;

class MicrosoftAuthController extends Controller
{
    protected $microsoftService;

    public function __construct(MicrosoftGraphServiceAuth $microsoftService)
    {
        $this->microsoftService = $microsoftService;
    }

    public function redirect()
    {
        $authUrl = $this->microsoftService->getAuthUrl();
        session(['oauth2state' => $this->microsoftService->getState()]);
        return redirect()->away($authUrl);
    }

    public function callback()
    {
        if (request()->has('error')) {
            return redirect()->route('login')->with('error', request('error_description'));
        }

        if (!request()->has('code') || !request()->has('state')) {
            return redirect()->route('login')->with('error', 'Invalid response from Microsoft');
        }

        if (request('state') !== session('oauth2state')) {
            session()->forget('oauth2state');
            return redirect()->route('login')->with('error', 'Invalid state');
        }

        try {
            $accessToken = $this->microsoftService->getAccessToken(request('code'));
            $microsoftUser = $this->microsoftService->getUser($accessToken->getToken());

            $user = $this->findOrCreateUser($microsoftUser);

            Auth::login($user, true);

            return redirect()->intended('/dashboard');

        } catch (\Exception $e) {
            return redirect()->route('login')->with('error', 'Unable to login: ' . $e->getMessage());
        }
    }

    protected function findOrCreateUser($microsoftUser)
    {
        $user = User::where('email', $microsoftUser->getMail())->first();

        if (!$user) {
            $user = User::create([
                'name' => $microsoftUser->getDisplayName(),
                'email' => $microsoftUser->getMail(),
                'password' => bcrypt(str_random(16)),
                'microsoft_id' => $microsoftUser->getId(),
            ]);
        }

        return $user;
    }
}
