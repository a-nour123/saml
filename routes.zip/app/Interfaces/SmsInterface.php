<?php

namespace App\Interfaces;

interface SmsInterface
{
    public function sendSms($userId,$message);
}
